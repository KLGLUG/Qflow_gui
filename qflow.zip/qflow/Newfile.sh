cd ~/Documents/project1/source
gedit map9v3.v

