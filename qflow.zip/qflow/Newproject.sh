cd ~/Documents/
mkdir project1
cd project1
mkdir source synthesis layout
