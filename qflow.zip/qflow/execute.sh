cd ~/Documents/project1
qflow synthesize place route map9v3
